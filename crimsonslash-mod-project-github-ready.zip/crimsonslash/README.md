# Crimson Slash (Minecraft 1.20.1, Forge 47.x)

Custom sword with a fully custom, procedurally rendered sweeping slash
(wind-up -> slash -> fade-out), server-validated arc damage and multiplayer sync.

## Build the .jar (one time setup)

1. Download the **Forge 1.20.1 MDK 47.3.0**: https://files.minecraftforge.net/net/minecraftforge/forge/index_1.20.1.html
2. From the MDK copy **`gradlew`, `gradlew.bat` and the `gradle/` folder** into this project's root
   (they hold the Gradle 8.1.1 wrapper that ForgeGradle 6 needs).
3. Install JDK 17, then run in this folder:

       ./gradlew build          (Windows: gradlew build)

4. The mod jar is `build/libs/crimsonslash-1.0.0.jar`. Put it in your `mods/` folder
   (Forge 1.20.1-47.x). Server and client both need it.

## Run in dev
Open the folder in IntelliJ (import as Gradle project), run `./gradlew genIntellijRuns`, start `runClient`.

## Test
- Creative > Combat tab > **Crimson Blade** (or `/give @s crimsonslash:crimson_blade`).
- Swing at air and at mobs. Press F5 to check third person. A second client/LAN world shows it to others.
- Client config (`config/crimsonslash-client.toml`): `enabled`, `segments`, `intensity`.

## Layout
- `item/` SlashSwordItem, SlashProperties (radius, arc, colors, duration, style, sound...), SlashStyle
- `combat/` server hit detection + cooldown, attack event hook
- `animation/` timeline (SlashInstance), shared geometry (SlashBasis), easing
- `client/` + `client/renderer/` mesh rendering, local prediction, effect manager
- `network/` swing (C2S) and effect (S2C) packets
- `registry/` items, sounds

## Making more swords
Register another `SlashSwordItem` in `ModItems` with different `SlashProperties`
(`SlashStyle.DIAGONAL` / `OVERHEAD`, other colors, radius, arc, duration, `glow(false)` ...), then add
a model JSON, texture and lang entry for it.

## Build automatically on GitHub (no local Java installation needed)

1. Upload the **contents** of this `crimsonslash` folder to the root of a GitHub repository.
2. Open the repository's **Actions** tab. If prompted, enable GitHub Actions.
3. Select **Build CrimsonSlash Mod** and choose **Run workflow** (or push a commit).
4. When the run succeeds, open the run and download the `crimsonslash-forge-1.20.1` artifact.
5. Extract the downloaded artifact ZIP; the `.jar` inside is the mod file.

This workflow installs JDK 17 and Gradle 8.1.1 on GitHub's runner, so the project does not need a local Gradle wrapper. It still downloads Forge/Minecraft build dependencies from their official repositories during the build.
