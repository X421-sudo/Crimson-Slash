package com.example.crimsonslash;

import com.example.crimsonslash.config.ClientConfig;
import com.example.crimsonslash.network.SlashNetwork;
import com.example.crimsonslash.registry.ModItems;
import com.example.crimsonslash.registry.ModSounds;
import com.mojang.logging.LogUtils;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraftforge.event.BuildCreativeModeTabContentsEvent;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.ModLoadingContext;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.config.ModConfig;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import org.slf4j.Logger;

@Mod(CrimsonSlash.MOD_ID)
public class CrimsonSlash {

    public static final String MOD_ID = "crimsonslash";
    public static final Logger LOGGER = LogUtils.getLogger();

    public CrimsonSlash() {
        IEventBus modBus = FMLJavaModLoadingContext.get().getModEventBus();

        ModItems.ITEMS.register(modBus);
        ModSounds.SOUNDS.register(modBus);

        modBus.addListener(this::commonSetup);
        modBus.addListener(this::addCreative);

        // Only uses Forge config classes, so it is safe to reference on a dedicated server.
        ModLoadingContext.get().registerConfig(ModConfig.Type.CLIENT, ClientConfig.SPEC);
    }

    private void commonSetup(final FMLCommonSetupEvent event) {
        event.enqueueWork(SlashNetwork::register);
        LOGGER.info("[{}] Common setup complete.", MOD_ID);
    }

    private void addCreative(final BuildCreativeModeTabContentsEvent event) {
        if (event.getTabKey() == CreativeModeTabs.COMBAT) {
            event.accept(ModItems.CRIMSON_BLADE);
        }
    }
}
