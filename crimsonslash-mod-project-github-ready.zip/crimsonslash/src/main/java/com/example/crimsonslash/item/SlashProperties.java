package com.example.crimsonslash.item;

import net.minecraft.sounds.SoundEvent;

import java.util.function.Supplier;

/** Immutable description of how a sword's slash looks and behaves. Safe to use on both sides. */
public final class SlashProperties {

    private final int color;
    private final int coreColor;
    private final float radius;
    private final float arcDegrees;
    private final float width;
    private final SlashStyle style;
    private final int durationTicks;
    private final int cooldownTicks;
    private final float windUpFraction;
    private final float slashFraction;
    private final float damageRatio;
    private final float knockback;
    private final float verticalReach;
    private final int igniteSeconds;
    private final boolean glow;
    private final Supplier<SoundEvent> sound;

    private SlashProperties(Builder b) {
        this.color = b.color;
        this.coreColor = b.coreColor;
        this.radius = b.radius;
        this.arcDegrees = b.arcDegrees;
        this.width = b.width;
        this.style = b.style;
        this.durationTicks = b.durationTicks;
        this.cooldownTicks = b.cooldownTicks;
        this.windUpFraction = b.windUpFraction;
        this.slashFraction = b.slashFraction;
        this.damageRatio = b.damageRatio;
        this.knockback = b.knockback;
        this.verticalReach = b.verticalReach;
        this.igniteSeconds = b.igniteSeconds;
        this.glow = b.glow;
        this.sound = b.sound;
    }

    public int color() { return color; }
    public int coreColor() { return coreColor; }
    public float radius() { return radius; }
    public float arcDegrees() { return arcDegrees; }
    public float width() { return width; }
    public SlashStyle style() { return style; }
    public int durationTicks() { return durationTicks; }
    public int cooldownTicks() { return cooldownTicks; }
    public float windUpFraction() { return windUpFraction; }
    public float slashFraction() { return slashFraction; }
    public float damageRatio() { return damageRatio; }
    public float knockback() { return knockback; }
    public float verticalReach() { return verticalReach; }
    public int igniteSeconds() { return igniteSeconds; }
    public boolean glow() { return glow; }
    public Supplier<SoundEvent> sound() { return sound; }

    public static Builder builder() {
        return new Builder();
    }

    public static final class Builder {
        private int color = 0xFF3355;
        private int coreColor = 0xFFFFFF;
        private float radius = 3.2F;
        private float arcDegrees = 150.0F;
        private float width = 1.0F;
        private SlashStyle style = SlashStyle.CRESCENT;
        private int durationTicks = 12;
        private int cooldownTicks = 10;
        private float windUpFraction = 0.2F;
        private float slashFraction = 0.3F;
        private float damageRatio = 0.75F;
        private float knockback = 0.4F;
        private float verticalReach = 1.0F;
        private int igniteSeconds = 0;
        private boolean glow = true;
        private Supplier<SoundEvent> sound = () -> null;

        public Builder color(int rgb) { this.color = rgb; return this; }
        public Builder coreColor(int rgb) { this.coreColor = rgb; return this; }
        public Builder radius(float radius) { this.radius = radius; return this; }
        public Builder arcDegrees(float degrees) { this.arcDegrees = degrees; return this; }
        public Builder width(float width) { this.width = width; return this; }
        public Builder style(SlashStyle style) { this.style = style; return this; }
        public Builder durationTicks(int ticks) { this.durationTicks = ticks; return this; }
        public Builder cooldownTicks(int ticks) { this.cooldownTicks = ticks; return this; }
        public Builder phases(float windUpFraction, float slashFraction) {
            this.windUpFraction = windUpFraction;
            this.slashFraction = slashFraction;
            return this;
        }
        public Builder damageRatio(float ratio) { this.damageRatio = ratio; return this; }
        public Builder knockback(float knockback) { this.knockback = knockback; return this; }
        public Builder verticalReach(float reach) { this.verticalReach = reach; return this; }
        public Builder igniteSeconds(int seconds) { this.igniteSeconds = seconds; return this; }
        public Builder glow(boolean glow) { this.glow = glow; return this; }
        public Builder sound(Supplier<SoundEvent> sound) { this.sound = sound; return this; }

        public SlashProperties build() {
            if (durationTicks < 4) {
                throw new IllegalStateException("durationTicks must be at least 4");
            }
            if (windUpFraction < 0.0F || slashFraction <= 0.0F || windUpFraction + slashFraction > 0.9F) {
                throw new IllegalStateException("windUp + slash fractions must leave room for the fade-out");
            }
            return new SlashProperties(this);
        }
    }
}
