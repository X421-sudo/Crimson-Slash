package com.example.crimsonslash.animation;

public enum SlashPhase {
    WIND_UP,
    SLASH,
    FADE_OUT
}
