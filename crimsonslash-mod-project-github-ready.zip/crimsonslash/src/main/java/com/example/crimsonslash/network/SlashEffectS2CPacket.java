package com.example.crimsonslash.network;

import com.example.crimsonslash.client.ClientSlashPacketHandler;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

/** Server -> client: play a slash animation on the given entity. */
public record SlashEffectS2CPacket(int entityId, ResourceLocation itemId, float yaw, float pitch, boolean flip) {

    public void encode(FriendlyByteBuf buf) {
        buf.writeVarInt(entityId);
        buf.writeResourceLocation(itemId);
        buf.writeFloat(yaw);
        buf.writeFloat(pitch);
        buf.writeBoolean(flip);
    }

    public static SlashEffectS2CPacket decode(FriendlyByteBuf buf) {
        return new SlashEffectS2CPacket(buf.readVarInt(), buf.readResourceLocation(),
                buf.readFloat(), buf.readFloat(), buf.readBoolean());
    }

    public void handle(Supplier<NetworkEvent.Context> ctxSupplier) {
        NetworkEvent.Context ctx = ctxSupplier.get();
        ctx.enqueueWork(() ->
                DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () -> ClientSlashPacketHandler.handle(this)));
        ctx.setPacketHandled(true);
    }
}
