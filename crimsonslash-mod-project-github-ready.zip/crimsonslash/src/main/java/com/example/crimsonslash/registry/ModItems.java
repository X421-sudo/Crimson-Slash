package com.example.crimsonslash.registry;

import com.example.crimsonslash.CrimsonSlash;
import com.example.crimsonslash.item.SlashProperties;
import com.example.crimsonslash.item.SlashStyle;
import com.example.crimsonslash.item.SlashSwordItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.Tiers;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public final class ModItems {

    public static final DeferredRegister<Item> ITEMS =
            DeferredRegister.create(ForgeRegistries.ITEMS, CrimsonSlash.MOD_ID);

    /** Example sword demonstrating the full slash system. */
    public static final RegistryObject<Item> CRIMSON_BLADE = ITEMS.register("crimson_blade",
            () -> new SlashSwordItem(
                    Tiers.NETHERITE,
                    3,          // attack damage modifier (added to tier bonus + base 1)
                    -2.4F,      // attack speed modifier
                    new Item.Properties().rarity(Rarity.EPIC).fireResistant(),
                    SlashProperties.builder()
                            .color(0xFF2A4A)
                            .coreColor(0xFFE8EC)
                            .radius(3.4F)
                            .arcDegrees(160.0F)
                            .width(1.1F)
                            .style(SlashStyle.CRESCENT)
                            .durationTicks(14)
                            .cooldownTicks(10)
                            .phases(0.2F, 0.3F)
                            .damageRatio(0.8F)
                            .knockback(0.5F)
                            .verticalReach(1.2F)
                            .igniteSeconds(3)
                            .glow(true)
                            .sound(ModSounds.SLASH)
                            .build()));

    private ModItems() {
    }
}
