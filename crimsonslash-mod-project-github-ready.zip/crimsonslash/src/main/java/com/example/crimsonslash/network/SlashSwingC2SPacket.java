package com.example.crimsonslash.network;

import com.example.crimsonslash.combat.SlashCombat;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

/** Client -> server: "I swung at empty air". The server validates everything itself. */
public record SlashSwingC2SPacket() {

    public void encode(FriendlyByteBuf buf) {
    }

    public static SlashSwingC2SPacket decode(FriendlyByteBuf buf) {
        return new SlashSwingC2SPacket();
    }

    public void handle(Supplier<NetworkEvent.Context> ctxSupplier) {
        NetworkEvent.Context ctx = ctxSupplier.get();
        ctx.enqueueWork(() -> {
            ServerPlayer player = ctx.getSender();
            if (player != null) {
                SlashCombat.performSlash(player, player.getMainHandItem(), null);
            }
        });
        ctx.setPacketHandled(true);
    }
}
