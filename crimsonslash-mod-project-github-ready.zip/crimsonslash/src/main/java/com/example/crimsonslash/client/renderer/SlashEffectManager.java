package com.example.crimsonslash.client.renderer;

import com.example.crimsonslash.animation.SlashInstance;
import net.minecraft.client.multiplayer.ClientLevel;

import java.util.ArrayList;
import java.util.List;

/** Holds all currently playing slash animations on this client. */
public final class SlashEffectManager {

    private static final int MAX_ACTIVE = 64;
    private static final List<SlashInstance> ACTIVE = new ArrayList<>();

    public static void add(SlashInstance instance) {
        if (ACTIVE.size() >= MAX_ACTIVE) {
            ACTIVE.remove(0);
        }
        ACTIVE.add(instance);
    }

    public static List<SlashInstance> active() {
        return ACTIVE;
    }

    public static void tick(ClientLevel level) {
        ACTIVE.removeIf(instance -> {
            instance.tick();
            return instance.isFinished() || level.getEntity(instance.entityId()) == null;
        });
    }

    public static void clear() {
        ACTIVE.clear();
    }

    private SlashEffectManager() {
    }
}
