package com.example.crimsonslash.client;

import com.example.crimsonslash.CrimsonSlash;
import com.example.crimsonslash.animation.SlashInstance;
import com.example.crimsonslash.client.renderer.SlashEffectManager;
import com.example.crimsonslash.combat.CombatEvents;
import com.example.crimsonslash.item.SlashSwordItem;
import com.example.crimsonslash.network.SlashNetwork;
import com.example.crimsonslash.network.SlashSwingC2SPacket;
import net.minecraft.client.Minecraft;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.event.entity.player.AttackEntityEvent;
import net.minecraftforge.event.entity.player.PlayerInteractEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/**
 * Client prediction for the local player so the slash appears instantly with no network round trip.
 * Damage is never decided here; the server re-validates everything.
 */
@Mod.EventBusSubscriber(modid = CrimsonSlash.MOD_ID, bus = Mod.EventBusSubscriber.Bus.FORGE, value = Dist.CLIENT)
public final class ClientCombatEvents {

    private static long nextLocalSlash = 0L;
    private static boolean localFlip = false;

    /** Swing at empty air: predict locally and tell the server. */
    @SubscribeEvent
    public static void onLeftClickEmpty(PlayerInteractEvent.LeftClickEmpty event) {
        ItemStack stack = event.getItemStack();
        if (stack.getItem() instanceof SlashSwordItem sword && startLocal(event.getEntity(), sword)) {
            SlashNetwork.CHANNEL.sendToServer(new SlashSwingC2SPacket());
        }
    }

    /** Melee hit on an entity: the server handles the hit itself, we only predict the visual. */
    @SubscribeEvent
    public static void onAttackEntity(AttackEntityEvent event) {
        Player player = event.getEntity();
        if (!player.level().isClientSide() || player != Minecraft.getInstance().player) {
            return;
        }
        ItemStack stack = player.getMainHandItem();
        if (!(stack.getItem() instanceof SlashSwordItem sword) || !event.getTarget().isAttackable()) {
            return;
        }
        if (player.getAttackStrengthScale(0.5F) < CombatEvents.MIN_STRENGTH) {
            return;
        }
        startLocal(player, sword);
    }

    private static boolean startLocal(Player player, SlashSwordItem sword) {
        long now = player.level().getGameTime();
        if (now < nextLocalSlash) {
            return false;
        }
        nextLocalSlash = now + sword.getSlashProperties().cooldownTicks();
        SlashEffectManager.add(new SlashInstance(player.getId(), sword.getSlashProperties(),
                player.getYRot(), player.getXRot(), localFlip));
        localFlip = !localFlip;
        return true;
    }

    private ClientCombatEvents() {
    }
}
