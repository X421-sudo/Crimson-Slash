package com.example.crimsonslash.animation;

import com.example.crimsonslash.item.SlashProperties;
import net.minecraft.util.Mth;

/**
 * One running slash animation (client-side state, but contains no client-only classes).
 * Timeline: WIND_UP -> SLASH -> FADE_OUT, expressed as fractions of the total duration.
 * Positions along the sweep are expressed as p in [0,1] (0 = start of sweep, 1 = end).
 */
public final class SlashInstance {

    private static final float PULLBACK = -0.06F;
    private static final float MAX_TRAIL = 0.55F;
    private static final float MIN_TRAIL = 0.10F;
    private static final float OVERSHOOT = 0.04F;

    private final int entityId;
    private final SlashProperties props;
    private final boolean flip;
    private final SlashBasis basis;
    private final float startAngle;
    private final float endAngle;
    private int age;

    public SlashInstance(int entityId, SlashProperties props, float yawDeg, float pitchDeg, boolean flip) {
        this.entityId = entityId;
        this.props = props;
        this.flip = flip;
        float tilt = props.style().tiltDegrees() * (flip ? -1.0F : 1.0F);
        this.basis = SlashBasis.of(yawDeg, pitchDeg, tilt);
        float half = (float) Math.toRadians(props.arcDegrees()) * 0.5F;
        float sign = flip ? 1.0F : -1.0F;
        this.startAngle = -sign * half;
        this.endAngle = sign * half;
    }

    public record Frame(float head, float tail, float alpha, float width, SlashPhase phase) {
    }

    public void tick() {
        age++;
    }

    public boolean isFinished() {
        return age >= props.durationTicks();
    }

    public int entityId() { return entityId; }
    public SlashProperties properties() { return props; }
    public boolean flipped() { return flip; }
    public SlashBasis basis() { return basis; }
    public float startAngle() { return startAngle; }
    public float endAngle() { return endAngle; }

    public Frame frame(float partialTick) {
        float total = Math.max(1.0F, props.durationTicks());
        float u = Mth.clamp((age + partialTick) / total, 0.0F, 1.0F);
        float w = props.windUpFraction();
        float s = Math.max(props.slashFraction(), 1.0E-4F);
        float windEnd = w;
        float slashEnd = w + s;

        if (u < windEnd) {
            float k = Easing.outCubic(w <= 0.0F ? 1.0F : u / w);
            float head = PULLBACK * k;
            return new Frame(head, head - MIN_TRAIL * k, 0.35F * k, 0.35F, SlashPhase.WIND_UP);
        }

        if (u < slashEnd) {
            float k = Mth.clamp((u - windEnd) / s, 0.0F, 1.0F);
            float head = Mth.lerp(Easing.outCubic(k), PULLBACK, 1.0F);
            float len = Mth.lerp(Easing.outQuad(k), MIN_TRAIL, MAX_TRAIL);
            float tail = Math.max(head - len, PULLBACK - MIN_TRAIL);
            float alpha = Mth.lerp(k, 0.35F, 1.0F);
            float width = Mth.lerp(Easing.outQuad(k), 0.35F, 1.0F);
            return new Frame(head, tail, alpha, width, SlashPhase.SLASH);
        }

        float fadeSpan = Math.max(1.0F - slashEnd, 1.0E-4F);
        float k = Mth.clamp((u - slashEnd) / fadeSpan, 0.0F, 1.0F);
        float head = 1.0F + OVERSHOOT * Easing.outCubic(k);
        float tailStart = 1.0F - MAX_TRAIL;
        float tail = Mth.lerp(Easing.inQuad(k), tailStart, head);
        float alpha = (float) Math.pow(1.0F - k, 1.5D);
        float width = Mth.lerp(k, 1.0F, 0.5F);
        return new Frame(head, tail, alpha, width, SlashPhase.FADE_OUT);
    }
}
