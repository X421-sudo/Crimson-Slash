package com.example.crimsonslash.config;

import net.minecraftforge.common.ForgeConfigSpec;

/** Client-side visual settings. Contains no Minecraft client classes, so it is server-safe to load. */
public final class ClientConfig {

    public static final ForgeConfigSpec SPEC;
    public static final ForgeConfigSpec.BooleanValue ENABLE_SLASH;
    public static final ForgeConfigSpec.IntValue SEGMENTS;
    public static final ForgeConfigSpec.DoubleValue INTENSITY;

    static {
        ForgeConfigSpec.Builder builder = new ForgeConfigSpec.Builder();
        builder.push("slash");
        ENABLE_SLASH = builder.comment("Render the custom slash effect.")
                .define("enabled", true);
        SEGMENTS = builder.comment("Mesh smoothness of the slash arc. Higher is smoother.")
                .defineInRange("segments", 28, 8, 96);
        INTENSITY = builder.comment("Brightness multiplier of the slash effect.")
                .defineInRange("intensity", 1.0D, 0.1D, 2.0D);
        builder.pop();
        SPEC = builder.build();
    }

    private ClientConfig() {
    }
}
