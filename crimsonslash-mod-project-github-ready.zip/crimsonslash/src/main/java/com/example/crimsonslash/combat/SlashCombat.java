package com.example.crimsonslash.combat;

import com.example.crimsonslash.animation.SlashBasis;
import com.example.crimsonslash.item.SlashProperties;
import com.example.crimsonslash.item.SlashSwordItem;
import com.example.crimsonslash.network.SlashEffectS2CPacket;
import com.example.crimsonslash.network.SlashNetwork;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.TamableAnimal;
import net.minecraft.world.entity.decoration.ArmorStand;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.enchantment.EnchantmentHelper;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.network.PacketDistributor;
import net.minecraftforge.registries.ForgeRegistries;

import javax.annotation.Nullable;
import java.util.ArrayList;
import java.util.List;

/** Server-authoritative slash logic. Never touches client-only classes. */
public final class SlashCombat {

    private static final String NEXT_SLASH_TAG = "crimsonslash_next_slash";
    private static final String FLIP_TAG = "crimsonslash_flip";

    /**
     * Attempts to perform a slash for the given player. Validates cooldown and held item on the server.
     *
     * @param primary the entity already being hit by the vanilla attack (excluded from arc damage), or null
     * @return true if the slash happened
     */
    public static boolean performSlash(ServerPlayer player, ItemStack stack, @Nullable Entity primary) {
        if (!(stack.getItem() instanceof SlashSwordItem sword)) {
            return false;
        }
        if (!player.isAlive() || player.isSpectator()) {
            return false;
        }

        ServerLevel level = (ServerLevel) player.level();
        long now = level.getGameTime();
        CompoundTag data = player.getPersistentData();
        if (now < data.getLong(NEXT_SLASH_TAG)) {
            return false; // still on cooldown: also blocks spam from forged packets
        }

        SlashProperties props = sword.getSlashProperties();
        data.putLong(NEXT_SLASH_TAG, now + props.cooldownTicks());
        boolean flip = data.getBoolean(FLIP_TAG);
        data.putBoolean(FLIP_TAG, !flip);

        float strength = primary != null ? Mth.clamp(player.getAttackStrengthScale(0.5F), 0.0F, 1.0F) : 1.0F;

        float yaw = player.getYRot();
        float pitch = player.getXRot();
        float tilt = props.style().tiltDegrees() * (flip ? -1.0F : 1.0F);
        SlashBasis basis = SlashBasis.of(yaw, pitch, tilt);
        Vec3 origin = SlashBasis.origin(player.position(), player.getEyeHeight());

        // Each entity is collected exactly once per slash, so nobody is damaged twice by one swing.
        List<LivingEntity> targets = findTargets(player, props, basis, origin, primary);

        DamageSource source = player.damageSources().playerAttack(player);
        float baseDamage = (float) player.getAttributeValue(Attributes.ATTACK_DAMAGE);
        int fireAspect = EnchantmentHelper.getFireAspect(player);
        int hits = 0;

        for (LivingEntity target : targets) {
            float bonus = EnchantmentHelper.getDamageBonus(stack, target.getMobType());
            float damage = (baseDamage + bonus) * props.damageRatio() * strength;
            if (damage <= 0.0F) {
                continue;
            }
            if (target.hurt(source, damage)) {
                hits++;
                if (props.knockback() > 0.0F) {
                    target.knockback(props.knockback(),
                            Mth.sin(yaw * Mth.DEG_TO_RAD), -Mth.cos(yaw * Mth.DEG_TO_RAD));
                }
                applyFire(target, props, fireAspect);
            }
        }

        // The primary target takes vanilla damage; the sword's special ability still applies to it.
        if (primary instanceof LivingEntity livingPrimary) {
            applyFire(livingPrimary, props, fireAspect);
        }

        if (hits > 0) {
            stack.hurtAndBreak(1, player, p -> p.broadcastBreakEvent(InteractionHand.MAIN_HAND));
        }

        SoundEvent sound = props.sound().get();
        if (sound != null) {
            level.playSound(null, player.getX(), player.getY(), player.getZ(), sound,
                    SoundSource.PLAYERS, 1.0F, 0.95F + level.random.nextFloat() * 0.15F);
        }

        // The attacker already predicted the animation locally, so only notify OTHER tracking players.
        SlashNetwork.CHANNEL.send(PacketDistributor.TRACKING_ENTITY.with(() -> player),
                new SlashEffectS2CPacket(player.getId(), ForgeRegistries.ITEMS.getKey(sword), yaw, pitch, flip));
        return true;
    }

    private static void applyFire(LivingEntity target, SlashProperties props, int fireAspectLevel) {
        int seconds = Math.max(props.igniteSeconds(), fireAspectLevel * 4);
        if (seconds > 0) {
            target.setSecondsOnFire(seconds);
        }
    }

    private static List<LivingEntity> findTargets(ServerPlayer player, SlashProperties props, SlashBasis basis,
                                                  Vec3 origin, @Nullable Entity primary) {
        double reach = props.radius();
        double halfArc = Math.toRadians(props.arcDegrees()) * 0.5D;
        AABB search = new AABB(origin, origin).inflate(reach + 2.0D);
        List<LivingEntity> result = new ArrayList<>();

        for (LivingEntity entity : player.level().getEntitiesOfClass(LivingEntity.class, search)) {
            if (entity == player || entity == primary || !entity.isAlive() || entity.isSpectator()) {
                continue;
            }
            if (entity instanceof ArmorStand || !entity.isAttackable() || player.isAlliedTo(entity)) {
                continue;
            }
            if (entity instanceof TamableAnimal tamable && tamable.isOwnedBy(player)) {
                continue;
            }
            if (entity instanceof Player other && !player.canHarmPlayer(other)) {
                continue;
            }

            // Express the target in the slash plane's coordinates: the same space the renderer draws in.
            Vec3 rel = entity.getBoundingBox().getCenter().subtract(origin);
            double x = rel.dot(basis.forward());
            double s = rel.dot(basis.axis());
            double h = rel.dot(basis.normal());
            double inPlane = Math.sqrt(x * x + s * s);
            double slack = entity.getBbWidth() * 0.5D + 0.3D;

            if (inPlane > reach + slack) {
                continue;
            }
            double theta = Math.atan2(s, x);
            double allowed = halfArc + Math.atan2(slack, Math.max(inPlane, 0.5D));
            if (Math.abs(theta) > allowed) {
                continue;
            }
            if (Math.abs(h) > props.verticalReach() + entity.getBbHeight() * 0.5D) {
                continue;
            }
            result.add(entity);
        }
        return result;
    }

    private SlashCombat() {
    }
}
