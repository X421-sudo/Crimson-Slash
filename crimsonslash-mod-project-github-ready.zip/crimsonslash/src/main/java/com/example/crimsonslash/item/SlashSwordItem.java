package com.example.crimsonslash.item;

import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.SwordItem;
import net.minecraft.world.item.Tier;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;
import net.minecraftforge.common.ToolAction;
import net.minecraftforge.common.ToolActions;

import javax.annotation.Nullable;
import java.util.List;

public class SlashSwordItem extends SwordItem {

    private final SlashProperties slash;

    public SlashSwordItem(Tier tier, int attackDamage, float attackSpeed, Item.Properties properties,
                          SlashProperties slash) {
        super(tier, attackDamage, attackSpeed, properties);
        this.slash = slash;
    }

    public SlashProperties getSlashProperties() {
        return slash;
    }

    /** Disables the vanilla sweep attack; the custom slash replaces it. */
    @Override
    public boolean canPerformAction(ItemStack stack, ToolAction action) {
        if (action == ToolActions.SWORD_SWEEP) {
            return false;
        }
        return super.canPerformAction(stack, action);
    }

    @Override
    public void appendHoverText(ItemStack stack, @Nullable Level level, List<Component> tooltip, TooltipFlag flag) {
        tooltip.add(Component.translatable("tooltip.crimsonslash.slash").withStyle(ChatFormatting.RED));
        if (slash.igniteSeconds() > 0) {
            tooltip.add(Component.translatable("tooltip.crimsonslash.ignite", slash.igniteSeconds())
                    .withStyle(ChatFormatting.GOLD));
        }
        super.appendHoverText(stack, level, tooltip, flag);
    }
}
