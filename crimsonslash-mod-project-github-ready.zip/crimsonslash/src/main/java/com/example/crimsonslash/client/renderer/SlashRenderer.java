package com.example.crimsonslash.client.renderer;

import com.example.crimsonslash.animation.SlashBasis;
import com.example.crimsonslash.animation.SlashInstance;
import com.example.crimsonslash.config.ClientConfig;
import com.example.crimsonslash.item.SlashProperties;
import com.mojang.blaze3d.platform.GlStateManager;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.BufferBuilder;
import com.mojang.blaze3d.vertex.BufferUploader;
import com.mojang.blaze3d.vertex.DefaultVertexFormat;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.Tesselator;
import com.mojang.blaze3d.vertex.VertexFormat;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.renderer.GameRenderer;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.phys.Vec3;
import org.joml.Matrix4f;

import java.util.List;

/**
 * Draws each slash as a procedurally generated crescent ribbon in world space:
 * a bright outer edge fading to transparent inner edge, a thin white-hot core, and a head that
 * glows toward white. Rendered with additive blending for the glow, no culling, no depth writes.
 */
public final class SlashRenderer {

    private static final double MAX_DISTANCE_SQ = 128.0D * 128.0D;

    public static void render(PoseStack poseStack, Vec3 cam, float partial, ClientLevel level) {
        List<SlashInstance> instances = SlashEffectManager.active();
        if (instances.isEmpty()) {
            return;
        }
        Matrix4f matrix = poseStack.last().pose();
        drawBatch(true, instances, matrix, cam, partial, level);
        drawBatch(false, instances, matrix, cam, partial, level);
    }

    private static void drawBatch(boolean glow, List<SlashInstance> instances, Matrix4f matrix, Vec3 cam,
                                  float partial, ClientLevel level) {
        int segments = ClientConfig.SEGMENTS.get();
        float intensity = ClientConfig.INTENSITY.get().floatValue();

        BufferBuilder buf = Tesselator.getInstance().getBuilder();
        buf.begin(VertexFormat.Mode.QUADS, DefaultVertexFormat.POSITION_COLOR);
        int vertices = 0;

        for (SlashInstance instance : instances) {
            SlashProperties props = instance.properties();
            if (props.glow() != glow) {
                continue;
            }
            Entity entity = level.getEntity(instance.entityId());
            if (entity == null) {
                continue;
            }
            Vec3 pos = entity.getPosition(partial);
            if (pos.distanceToSqr(cam) > MAX_DISTANCE_SQ) {
                continue;
            }
            Vec3 origin = SlashBasis.origin(pos, entity.getEyeHeight());
            vertices += addSlash(buf, matrix, cam, origin, instance, partial, segments, intensity);
        }

        BufferBuilder.RenderedBuffer rendered = buf.end();
        if (vertices == 0) {
            rendered.release();
            return;
        }

        RenderSystem.enableBlend();
        if (glow) {
            RenderSystem.blendFunc(GlStateManager.SourceFactor.SRC_ALPHA, GlStateManager.DestFactor.ONE);
        } else {
            RenderSystem.defaultBlendFunc();
        }
        RenderSystem.disableCull();
        RenderSystem.enableDepthTest();
        RenderSystem.depthMask(false);
        RenderSystem.setShader(GameRenderer::getPositionColorShader);

        BufferUploader.drawWithShader(rendered);

        RenderSystem.depthMask(true);
        RenderSystem.enableCull();
        RenderSystem.defaultBlendFunc();
        RenderSystem.disableBlend();
    }

    private static int addSlash(BufferBuilder buf, Matrix4f m, Vec3 cam, Vec3 origin, SlashInstance instance,
                                float partial, int segments, float intensity) {
        SlashProperties props = instance.properties();
        SlashInstance.Frame f = instance.frame(partial);
        float span = f.head() - f.tail();
        if (span < 0.002F || f.alpha() < 0.004F) {
            return 0;
        }
        int n = Math.max(4, Math.round(segments * Mth.clamp(span, 0.15F, 1.0F)));
        int count = 0;
        // Main colored ribbon, with the head heating up toward white.
        count += ribbon(buf, m, cam, origin, instance, props, f, n, 1.0F, props.color(), 1.3F, 0.9F * intensity, true);
        // Thin white-hot core hugging the outer edge.
        count += ribbon(buf, m, cam, origin, instance, props, f, n, 0.35F, props.coreColor(), 1.8F, 0.85F * intensity, false);
        return count;
    }

    private static int ribbon(BufferBuilder buf, Matrix4f m, Vec3 cam, Vec3 origin, SlashInstance instance,
                              SlashProperties props, SlashInstance.Frame f, int n, float widthFraction, int rgb,
                              float alphaPower, float peakAlpha, boolean heat) {
        SlashBasis basis = instance.basis();
        float t0 = instance.startAngle();
        float t1 = instance.endAngle();
        float r0 = ((rgb >> 16) & 255) / 255.0F;
        float g0 = ((rgb >> 8) & 255) / 255.0F;
        float b0 = (rgb & 255) / 255.0F;

        float[] ox = new float[n + 1], oy = new float[n + 1], oz = new float[n + 1];
        float[] ix = new float[n + 1], iy = new float[n + 1], iz = new float[n + 1];
        float[] a = new float[n + 1], r = new float[n + 1], g = new float[n + 1], b = new float[n + 1];

        for (int i = 0; i <= n; i++) {
            float q = i / (float) n;                         // 0 = tail, 1 = head
            float p = Mth.lerp(q, f.tail(), f.head());       // position along the sweep
            double theta = t0 + p * (t1 - t0);

            float smooth = q * q * (3.0F - 2.0F * q);
            float taper = (float) Math.pow(smooth, 0.8D);    // tail tapers to a point
            float w = props.width() * f.width() * widthFraction * taper;
            float radius = props.radius() * (1.0F + 0.05F * Mth.sin(Mth.PI * q));

            // The ribbon is slightly bowl-shaped (outer edge raised) so it stays visible from the side.
            Vec3 outer = basis.point(origin, theta, radius, w * 0.22D).subtract(cam);
            Vec3 inner = basis.point(origin, theta, radius - w, -w * 0.22D).subtract(cam);
            ox[i] = (float) outer.x; oy[i] = (float) outer.y; oz[i] = (float) outer.z;
            ix[i] = (float) inner.x; iy[i] = (float) inner.y; iz[i] = (float) inner.z;

            a[i] = Mth.clamp(peakAlpha * f.alpha() * (float) Math.pow(q, alphaPower), 0.0F, 1.0F);
            float mix = heat ? (float) Math.pow(q, 6.0D) * 0.65F : 0.0F;
            r[i] = Mth.lerp(mix, r0, 1.0F);
            g[i] = Mth.lerp(mix, g0, 1.0F);
            b[i] = Mth.lerp(mix, b0, 1.0F);
        }

        for (int i = 0; i < n; i++) {
            int j = i + 1;
            buf.vertex(m, ix[i], iy[i], iz[i]).color(r[i], g[i], b[i], 0.0F).endVertex();
            buf.vertex(m, ox[i], oy[i], oz[i]).color(r[i], g[i], b[i], a[i]).endVertex();
            buf.vertex(m, ox[j], oy[j], oz[j]).color(r[j], g[j], b[j], a[j]).endVertex();
            buf.vertex(m, ix[j], iy[j], iz[j]).color(r[j], g[j], b[j], 0.0F).endVertex();
        }
        return n * 4;
    }

    private SlashRenderer() {
    }
}
