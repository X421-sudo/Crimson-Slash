package com.example.crimsonslash.registry;

import com.example.crimsonslash.CrimsonSlash;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvent;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public final class ModSounds {

    public static final DeferredRegister<SoundEvent> SOUNDS =
            DeferredRegister.create(ForgeRegistries.SOUND_EVENTS, CrimsonSlash.MOD_ID);

    public static final RegistryObject<SoundEvent> SLASH = register("slash");

    private static RegistryObject<SoundEvent> register(String name) {
        return SOUNDS.register(name,
                () -> SoundEvent.createVariableRangeEvent(new ResourceLocation(CrimsonSlash.MOD_ID, name)));
    }

    private ModSounds() {
    }
}
