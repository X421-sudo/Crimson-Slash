package com.example.crimsonslash.item;

/** Different slash animation styles. The tilt rotates the slash plane around the player's forward axis. */
public enum SlashStyle {
    /** Flat horizontal crescent; alternates left-to-right and right-to-left. */
    CRESCENT(0.0F),
    /** Diagonal cut; alternating swings form an X pattern. */
    DIAGONAL(38.0F),
    /** Vertical overhead chop. */
    OVERHEAD(90.0F);

    private final float tiltDegrees;

    SlashStyle(float tiltDegrees) {
        this.tiltDegrees = tiltDegrees;
    }

    public float tiltDegrees() {
        return tiltDegrees;
    }
}
