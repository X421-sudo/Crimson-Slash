package com.example.crimsonslash.animation;

import net.minecraft.world.phys.Vec3;

/**
 * Shared geometry of a slash, used by BOTH the renderer and the server hit detection so that
 * what you see is exactly what gets hit.
 *
 * <p>The slash lives in a plane that contains the player's look direction ({@code forward}).
 * {@code axis} is the in-plane direction perpendicular to forward (tilted by the style),
 * {@code normal} is perpendicular to the plane. A point on the arc at angle theta and radius r is
 * {@code origin + forward*cos(theta)*r + axis*sin(theta)*r}.</p>
 */
public record SlashBasis(Vec3 forward, Vec3 axis, Vec3 normal) {

    private static final double ORIGIN_HEIGHT_FACTOR = 0.72D;

    public static SlashBasis of(float yawDeg, float pitchDeg, float tiltDeg) {
        double yaw = Math.toRadians(yawDeg);
        double pitch = Math.toRadians(pitchDeg);
        double tilt = Math.toRadians(tiltDeg);

        Vec3 forward = new Vec3(
                -Math.sin(yaw) * Math.cos(pitch),
                -Math.sin(pitch),
                Math.cos(yaw) * Math.cos(pitch));
        Vec3 right = new Vec3(-Math.cos(yaw), 0.0D, -Math.sin(yaw));
        Vec3 up = right.cross(forward);

        Vec3 axis = right.scale(Math.cos(tilt)).add(up.scale(Math.sin(tilt)));
        Vec3 normal = right.scale(-Math.sin(tilt)).add(up.scale(Math.cos(tilt)));
        return new SlashBasis(forward, axis, normal);
    }

    /** Center of the arc: roughly shoulder height of the entity. */
    public static Vec3 origin(Vec3 entityPosition, float eyeHeight) {
        return entityPosition.add(0.0D, eyeHeight * ORIGIN_HEIGHT_FACTOR, 0.0D);
    }

    public Vec3 point(Vec3 origin, double theta, double radius, double lift) {
        return origin
                .add(forward.scale(Math.cos(theta) * radius))
                .add(axis.scale(Math.sin(theta) * radius))
                .add(normal.scale(lift));
    }
}
