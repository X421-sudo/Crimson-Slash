package com.example.crimsonslash.network;

import com.example.crimsonslash.CrimsonSlash;
import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.network.NetworkDirection;
import net.minecraftforge.network.NetworkRegistry;
import net.minecraftforge.network.simple.SimpleChannel;

import java.util.Optional;

public final class SlashNetwork {

    private static final String PROTOCOL = "1";

    public static final SimpleChannel CHANNEL = NetworkRegistry.newSimpleChannel(
            new ResourceLocation(CrimsonSlash.MOD_ID, "main"),
            () -> PROTOCOL, PROTOCOL::equals, PROTOCOL::equals);

    public static void register() {
        int id = 0;
        CHANNEL.registerMessage(id++, SlashSwingC2SPacket.class,
                SlashSwingC2SPacket::encode, SlashSwingC2SPacket::decode, SlashSwingC2SPacket::handle,
                Optional.of(NetworkDirection.PLAY_TO_SERVER));
        CHANNEL.registerMessage(id++, SlashEffectS2CPacket.class,
                SlashEffectS2CPacket::encode, SlashEffectS2CPacket::decode, SlashEffectS2CPacket::handle,
                Optional.of(NetworkDirection.PLAY_TO_CLIENT));
    }

    private SlashNetwork() {
    }
}
