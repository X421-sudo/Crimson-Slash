package com.example.crimsonslash.combat;

import com.example.crimsonslash.CrimsonSlash;
import com.example.crimsonslash.item.SlashSwordItem;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.event.entity.player.AttackEntityEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/** Server-side detection of normal melee attacks with a slash sword. */
@Mod.EventBusSubscriber(modid = CrimsonSlash.MOD_ID, bus = Mod.EventBusSubscriber.Bus.FORGE)
public final class CombatEvents {

    /** Minimum attack-strength for a melee hit to also unleash the slash (mirrors vanilla's sweep rule). */
    public static final float MIN_STRENGTH = 0.9F;

    @SubscribeEvent
    public static void onAttackEntity(AttackEntityEvent event) {
        if (!(event.getEntity() instanceof ServerPlayer player)) {
            return;
        }
        ItemStack stack = player.getMainHandItem();
        if (!(stack.getItem() instanceof SlashSwordItem)) {
            return;
        }
        Entity target = event.getTarget();
        if (!target.isAttackable()) {
            return;
        }
        if (player.getAttackStrengthScale(0.5F) < MIN_STRENGTH) {
            return;
        }
        SlashCombat.performSlash(player, stack, target);
    }

    private CombatEvents() {
    }
}
