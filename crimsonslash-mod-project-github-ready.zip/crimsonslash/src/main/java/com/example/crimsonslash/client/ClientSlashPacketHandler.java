package com.example.crimsonslash.client;

import com.example.crimsonslash.animation.SlashInstance;
import com.example.crimsonslash.client.renderer.SlashEffectManager;
import com.example.crimsonslash.item.SlashSwordItem;
import com.example.crimsonslash.network.SlashEffectS2CPacket;
import net.minecraft.world.item.Item;
import net.minecraftforge.registries.ForgeRegistries;

/** Client-only. Only ever referenced through DistExecutor from the packet. */
public final class ClientSlashPacketHandler {

    public static void handle(SlashEffectS2CPacket packet) {
        Item item = ForgeRegistries.ITEMS.getValue(packet.itemId());
        if (item instanceof SlashSwordItem sword) {
            SlashEffectManager.add(new SlashInstance(packet.entityId(), sword.getSlashProperties(),
                    packet.yaw(), packet.pitch(), packet.flip()));
        }
    }

    private ClientSlashPacketHandler() {
    }
}
