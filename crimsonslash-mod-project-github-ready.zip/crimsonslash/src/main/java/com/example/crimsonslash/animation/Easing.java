package com.example.crimsonslash.animation;

public final class Easing {

    public static float outQuad(float t) {
        return 1.0F - (1.0F - t) * (1.0F - t);
    }

    public static float inQuad(float t) {
        return t * t;
    }

    public static float outCubic(float t) {
        float k = 1.0F - t;
        return 1.0F - k * k * k;
    }

    private Easing() {
    }
}
